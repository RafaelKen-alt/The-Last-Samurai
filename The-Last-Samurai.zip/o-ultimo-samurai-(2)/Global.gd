extends Node

var sword_collected := false
var sword_bonus_damage := 15
var equipped_weapon := "fists"
var loaded_lives := 3
var should_apply_loaded_lives := false



# Settings persistence
var volume_level: float = 70.0
var is_fullscreen: bool = false
var graphics_quality: int = 2

# Reference to the active camera
var camera: Camera2D = null

# Hitstop / Game Freeze effect
func trigger_hitstop(duration: float = 0.08) -> void:
	Engine.time_scale = 0.05
	# Wait using a real-time timer that ignores time scale
	if get_tree():
		await get_tree().create_timer(duration * 0.05, true, false, true).timeout
	Engine.time_scale = 1.0

# Spawn floating damage numbers programmatically
func spawn_damage_number(amount: int, pos: Vector2, is_crit: bool = false) -> void:
	if not get_tree() or not get_tree().current_scene:
		return
		
	var label := Label.new()
	if amount == 0 and is_crit:
		label.text = "PARRY!"
	elif amount == 0:
		label.text = "BLOQUEADO"
	else:
		label.text = str(amount)
	
	# Randomize starting position slightly
	label.global_position = pos + Vector2(randf_range(-25.0, 25.0), randf_range(-30.0, -10.0))
	
	# Styling
	if amount == 0 and is_crit:
		label.add_theme_color_override("font_color", Color(0.2, 1.0, 1.0)) # Cyan
	elif amount == 0:
		label.add_theme_color_override("font_color", Color(1.0, 1.0, 0.3)) # Yellow
	elif is_crit:
		label.add_theme_color_override("font_color", Color(1.0, 0.2, 0.2)) # Red crit
	else:
		label.add_theme_color_override("font_color", Color(1.0, 1.0, 0.9)) # Off-white
		
	label.add_theme_color_override("font_outline_color", Color(0, 0, 0))
	label.add_theme_constant_override("outline_size", 5)
	label.add_theme_font_size_override("font_size", 20 if (is_crit or amount == 0) else 16)
	
	get_tree().current_scene.add_child(label)
	
	# Animate float up and fade
	var tween := label.create_tween().set_parallel(true)
	tween.tween_property(label, "global_position:y", label.global_position.y - 70.0, 0.6).set_trans(Tween.TRANS_CUBIC).set_ease(Tween.EASE_OUT)
	tween.tween_property(label, "modulate:a", 0.0, 0.5).set_delay(0.2)
	
	tween.chain().tween_callback(label.queue_free)

# Spawn hit sparks programmatically at impact position
func spawn_hit_sparks(pos: Vector2) -> void:
	if not get_tree() or not get_tree().current_scene:
		return
		
	var particles := CPUParticles2D.new()
	particles.global_position = pos
	particles.amount = 15
	particles.lifetime = 0.35
	particles.one_shot = true
	particles.explosiveness = 0.85
	
	particles.direction = Vector2(0.0, -1.0)
	particles.spread = 180.0
	particles.gravity = Vector2(0.0, 120.0)
	particles.initial_velocity_min = 70.0
	particles.initial_velocity_max = 140.0
	
	particles.scale_amount_min = 2.0
	particles.scale_amount_max = 5.0
	particles.color = Color(1.0, 0.85, 0.2) # Bright golden spark
	
	get_tree().current_scene.add_child(particles)
	particles.emitting = true
	
	# Free after emission completes
	await get_tree().create_timer(particles.lifetime + 0.1, true, false, true).timeout
	particles.queue_free()

func save_game(current_scene_name: String, player_lives: int) -> bool:
	var save_dict = {
		"level": current_scene_name,
		"lives": player_lives,
		"sword_collected": sword_collected,
		"equipped_weapon": equipped_weapon
	}
	
	var file = FileAccess.open("user://savegame.json", FileAccess.WRITE)
	if not file:
		print("Falha ao guardar jogo!")
		return false
		
	var json_string = JSON.stringify(save_dict)
	file.store_line(json_string)
	file.close()
	print("Jogo guardado com sucesso: ", json_string)
	return true

func has_save_file() -> bool:
	return FileAccess.file_exists("user://savegame.json")

func load_game() -> Dictionary:
	if not has_save_file():
		return {}
		
	var file = FileAccess.open("user://savegame.json", FileAccess.READ)
	if not file:
		return {}
		
	var json_string = file.get_line()
	file.close()
	
	var json = JSON.new()
	var parse_result = json.parse(json_string)
	if not parse_result == OK:
		return {}
		
	var data = json.get_data()
	if typeof(data) == TYPE_DICTIONARY:
		return data
	return {}
