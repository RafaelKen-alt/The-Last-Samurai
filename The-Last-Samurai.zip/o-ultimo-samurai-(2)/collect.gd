extends Area2D

var coletado := false

func _ready() -> void:
	print("ITEM pronto")
	monitoring = true
	monitorable = true
	collision_layer = 4
	collision_mask = 2 # Detetar o jogador na camada 2
	body_entered.connect(_on_body_entered)
	area_entered.connect(_on_area_entered)

func _on_body_entered(body: Node2D) -> void:
	print("BODY entrou: ", body.name)
	if body.is_in_group("player"):
		Global.sword_collected = true
		if body.has_method("add_sword_to_inventory"):
			body.add_sword_to_inventory()
		coletar()

func _on_area_entered(area: Area2D) -> void:
	print("AREA entrou: ", area.name)
	var target_player: Node2D = null
	if area.is_in_group("player"):
		target_player = area
	elif area.get_parent().is_in_group("player"):
		target_player = area.get_parent()
		
	if target_player:
		Global.sword_collected = true
		if target_player.has_method("add_sword_to_inventory"):
			target_player.add_sword_to_inventory()
		coletar()

func coletar() -> void:
	if coletado:
		return

	coletado = true
	print("ITEM COLETADO")
	hide()
	queue_free()
