extends CanvasLayer

@onready var resume_button: Button = $Control/MenuContainer/ResumeButton
@onready var options_button: Button = $Control/MenuContainer/OptionsButton
@onready var quit_button: Button = $Control/MenuContainer/QuitButton

@onready var menu_container: VBoxContainer = $Control/MenuContainer
@onready var options_container: VBoxContainer = $Control/OptionsContainer

@onready var fullscreen_check: CheckButton = $Control/OptionsContainer/FullscreenCheck
@onready var volume_slider: HSlider = $Control/OptionsContainer/VolumeSlider
@onready var graphics_option: OptionButton = $Control/OptionsContainer/GraphicsOption
@onready var back_button: Button = $Control/OptionsContainer/BackButton

func _ready() -> void:
	hide()
	process_mode = Node.PROCESS_MODE_ALWAYS

	Input.mouse_mode = Input.MOUSE_MODE_CAPTURED

	# Setup buttons
	resume_button.pressed.connect(_on_resume_button_pressed)
	options_button.pressed.connect(_on_options_button_pressed)
	quit_button.pressed.connect(_on_quit_button_pressed)
	back_button.pressed.connect(_on_back_button_pressed)

	# Programmatic Save and Load buttons
	var save_btn := Button.new()
	save_btn.name = "SaveButton"
	save_btn.text = "Guardar Jogo"
	save_btn.pressed.connect(_on_save_game_pressed)
	menu_container.add_child(save_btn)
	menu_container.move_child(save_btn, 1) # put it right below ResumeButton
	
	var load_btn := Button.new()
	load_btn.name = "LoadButton"
	load_btn.text = "Carregar Jogo"
	load_btn.pressed.connect(_on_load_game_pressed)
	menu_container.add_child(load_btn)
	menu_container.move_child(load_btn, 2) # below SaveButton

	# Setup graphics option items
	graphics_option.clear()
	graphics_option.add_item("Baixo")
	graphics_option.add_item("Médio")
	graphics_option.add_item("Alto")

	# Connect settings signals
	fullscreen_check.toggled.connect(_on_fullscreen_toggled)
	volume_slider.value_changed.connect(_on_volume_changed)
	graphics_option.item_selected.connect(_on_graphics_selected)

	# Load initial settings from Global
	_load_settings()

func _process(_delta: float) -> void:
	if Input.is_action_just_pressed("Pause"):
		if visible:
			close_menu()
		else:
			open_menu()

func open_menu() -> void:
	show()
	menu_container.show()
	options_container.hide()
	get_tree().paused = true
	Input.mouse_mode = Input.MOUSE_MODE_VISIBLE

	# Refresh UI values in case they were updated externally
	_load_settings()

func close_menu() -> void:
	hide()
	get_tree().paused = false
	Input.mouse_mode = Input.MOUSE_MODE_CAPTURED

func _on_resume_button_pressed() -> void:
	close_menu()

func _on_options_button_pressed() -> void:
	menu_container.hide()
	options_container.show()

func _on_back_button_pressed() -> void:
	options_container.hide()
	menu_container.show()

func _on_quit_button_pressed() -> void:
	get_tree().paused = false
	Input.mouse_mode = Input.MOUSE_MODE_VISIBLE
	get_tree().quit()

# Option handlers
func _load_settings() -> void:
	fullscreen_check.button_pressed = Global.is_fullscreen
	volume_slider.value = Global.volume_level
	graphics_option.selected = Global.graphics_quality
	
	# Apply loaded settings on start
	_apply_fullscreen(Global.is_fullscreen)
	_apply_volume(Global.volume_level)
	_apply_graphics(Global.graphics_quality)

func _on_fullscreen_toggled(button_pressed: bool) -> void:
	Global.is_fullscreen = button_pressed
	_apply_fullscreen(button_pressed)

func _apply_fullscreen(is_fs: bool) -> void:
	if is_fs:
		DisplayServer.window_set_mode(DisplayServer.WINDOW_MODE_EXCLUSIVE_FULLSCREEN)
	else:
		DisplayServer.window_set_mode(DisplayServer.WINDOW_MODE_WINDOWED)

func _on_volume_changed(value: float) -> void:
	Global.volume_level = value
	_apply_volume(value)

func _apply_volume(value: float) -> void:
	var bus_index = AudioServer.get_bus_index("Master")
	if bus_index != -1:
		if value <= 0.0:
			AudioServer.set_bus_mute(bus_index, true)
		else:
			AudioServer.set_bus_mute(bus_index, false)
			# Convert 0-100 scale to dB range (-50 dB to 0 dB roughly)
			var volume_db = linear_to_db(value / 100.0)
			AudioServer.set_bus_volume_db(bus_index, volume_db)

func _on_graphics_selected(index: int) -> void:
	Global.graphics_quality = index
	_apply_graphics(index)

func _apply_graphics(index: int) -> void:
	match index:
		0: # Baixo
			DisplayServer.window_set_vsync_mode(DisplayServer.VSYNC_DISABLED)
			get_viewport().msaa_2d = Viewport.MSAA_DISABLED
			Engine.max_fps = 30
		1: # Médio
			DisplayServer.window_set_vsync_mode(DisplayServer.VSYNC_ENABLED)
			get_viewport().msaa_2d = Viewport.MSAA_2X
			Engine.max_fps = 60
		2: # Alto
			DisplayServer.window_set_vsync_mode(DisplayServer.VSYNC_ENABLED)
			get_viewport().msaa_2d = Viewport.MSAA_4X
			Engine.max_fps = 0 # uncapped

func _on_save_game_pressed() -> void:
	var player = get_tree().get_first_node_in_group("player")
	var player_lives = 3
	if player:
		player_lives = player.get("lives")
	
	var scene_path = get_tree().current_scene.scene_file_path
	if Global.save_game(scene_path, player_lives):
		if player and player.has_method("show_notification"):
			player.show_notification("Jogo Guardado com Sucesso!")
		close_menu()

func _on_load_game_pressed() -> void:
	var data = Global.load_game()
	if not data.is_empty():
		Global.sword_collected = data.get("sword_collected", false)
		Global.equipped_weapon = data.get("equipped_weapon", "fists")
		Global.set("loaded_lives", data.get("lives", 3))
		Global.set("should_apply_loaded_lives", true)
		
		var scene_path = data.get("level", "res://Floresta.tscn")
		close_menu()
		get_tree().paused = false
		get_tree().change_scene_to_file(scene_path)
