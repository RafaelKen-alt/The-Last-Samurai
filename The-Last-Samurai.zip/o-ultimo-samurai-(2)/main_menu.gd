extends CanvasLayer

@onready var resume_button: Button = $Control/MenuContainer/ResumeButton
@onready var options_button: Button = $Control/MenuContainer/OptionsButton
@onready var quit_button: Button = $Control/MenuContainer/QuitButton

@onready var menu_container: VBoxContainer = $Control/MenuContainer
@onready var options_container: VBoxContainer = $Control/OptionsContainer

@onready var fullscreen_check: CheckButton = $Control/OptionsContainer/FullscreenCheck
@onready var volume_slider: HSlider = $Control/OptionsContainer/VolumeSlider
@onready var graphics_option: OptionButton = $Control/OptionsContainer/GraphicsOption
@onready var back_button: Button = $Control/OptionsContainer/BackButton

func _ready() -> void:
	show()
	menu_container.show()
	options_container.hide()
	process_mode = Node.PROCESS_MODE_ALWAYS

	Input.mouse_mode = Input.MOUSE_MODE_VISIBLE

	# Make the background a solid dark samurai theme
	var bg = $Control/ColorRect
	if bg:
		bg.color = Color(0.06, 0.04, 0.04, 1.0) # Very dark near-black crimson

	# Setup buttons
	resume_button.text = "Novo Jogo"
	resume_button.pressed.connect(_on_new_game_pressed)
	options_button.pressed.connect(_on_options_button_pressed)
	quit_button.pressed.connect(_on_quit_button_pressed)
	back_button.pressed.connect(_on_back_button_pressed)

	# Programmatic Load button
	var load_btn := Button.new()
	load_btn.name = "LoadButton"
	load_btn.text = "Carregar Jogo"
	load_btn.pressed.connect(_on_load_game_pressed)
	menu_container.add_child(load_btn)
	menu_container.move_child(load_btn, 1) # place below Novo Jogo
	
	# Disable if no save game exists
	if not Global.has_save_file():
		load_btn.disabled = true

	# Style buttons to have a sleek dark glass / samurai red look
	var style_normal := StyleBoxFlat.new()
	style_normal.bg_color = Color(0.12, 0.08, 0.08, 0.6) # Dark transparent crimson
	style_normal.border_width_left = 3
	style_normal.border_color = Color(0.65, 0.12, 0.12, 0.8) # Samurai Red border
	style_normal.corner_radius_top_left = 4
	style_normal.corner_radius_bottom_left = 4
	style_normal.content_margin_left = 15
	style_normal.content_margin_top = 8
	style_normal.content_margin_bottom = 8

	var style_hover := StyleBoxFlat.new()
	style_hover.bg_color = Color(0.22, 0.06, 0.06, 0.8) # Richer dark red
	style_hover.border_width_left = 6
	style_hover.border_color = Color(0.95, 0.15, 0.15, 1.0) # Glowing Red border
	style_hover.corner_radius_top_left = 4
	style_hover.corner_radius_bottom_left = 4
	style_hover.content_margin_left = 20
	style_hover.content_margin_top = 8
	style_hover.content_margin_bottom = 8
	
	var style_disabled := StyleBoxFlat.new()
	style_disabled.bg_color = Color(0.05, 0.05, 0.05, 0.4)
	style_disabled.border_width_left = 3
	style_disabled.border_color = Color(0.3, 0.3, 0.3, 0.4)
	style_disabled.corner_radius_top_left = 4
	style_disabled.corner_radius_bottom_left = 4
	style_disabled.content_margin_left = 15
	style_disabled.content_margin_top = 8
	style_disabled.content_margin_bottom = 8

	for btn in menu_container.get_children():
		if btn is Button:
			btn.add_theme_stylebox_override("normal", style_normal)
			btn.add_theme_stylebox_override("hover", style_hover)
			btn.add_theme_stylebox_override("pressed", style_hover)
			btn.add_theme_stylebox_override("disabled", style_disabled)
			btn.add_theme_color_override("font_color", Color(0.9, 0.9, 0.9))
			btn.add_theme_color_override("font_hover_color", Color(1.0, 1.0, 1.0))
			btn.add_theme_font_size_override("font_size", 16)

	# Create Title and Subtitle container above MenuContainer
	var title_box := VBoxContainer.new()
	title_box.name = "TitleBox"
	title_box.custom_minimum_size = Vector2(376, 120)
	title_box.alignment = BoxContainer.ALIGNMENT_CENTER
	$Control.add_child(title_box)
	title_box.global_position = Vector2(501, 80)
	
	var title_lbl := Label.new()
	title_lbl.text = "O ÚLTIMO SAMURAI"
	title_lbl.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	title_lbl.add_theme_font_size_override("font_size", 44)
	title_lbl.add_theme_color_override("font_color", Color(0.85, 0.15, 0.15)) # Crimson red
	title_lbl.add_theme_color_override("font_outline_color", Color(0.0, 0.0, 0.0))
	title_lbl.add_theme_constant_override("outline_size", 10)
	title_box.add_child(title_lbl)
	
	var subtitle_lbl := Label.new()
	subtitle_lbl.text = "Menu Principal"
	subtitle_lbl.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	subtitle_lbl.add_theme_font_size_override("font_size", 18)
	subtitle_lbl.add_theme_color_override("font_color", Color(0.9, 0.8, 0.5)) # Pale Gold
	subtitle_lbl.add_theme_color_override("font_outline_color", Color(0, 0, 0))
	subtitle_lbl.add_theme_constant_override("outline_size", 6)
	title_box.add_child(subtitle_lbl)

	# Setup graphics option items
	graphics_option.clear()
	graphics_option.add_item("Baixo")
	graphics_option.add_item("Médio")
	graphics_option.add_item("Alto")

	# Connect settings signals
	fullscreen_check.toggled.connect(_on_fullscreen_toggled)
	volume_slider.value_changed.connect(_on_volume_changed)
	graphics_option.item_selected.connect(_on_graphics_selected)

	# Load initial settings from Global
	_load_settings()

	# Fade in animation for a premium starting impression
	$Control.modulate.a = 0.0
	var tween = create_tween()
	tween.tween_property($Control, "modulate:a", 1.0, 0.5)

func _process(_delta: float) -> void:
	if Input.is_action_just_pressed("Pause"):
		if options_container.visible:
			_on_back_button_pressed()

func _on_new_game_pressed() -> void:
	# Reset game progress variables
	Global.sword_collected = false
	Global.equipped_weapon = "fists"
	Global.loaded_lives = 3
	Global.should_apply_loaded_lives = false
	
	# Start the game (first level)
	get_tree().change_scene_to_file("res://Floresta.tscn")

func _on_options_button_pressed() -> void:
	menu_container.hide()
	options_container.show()

func _on_back_button_pressed() -> void:
	options_container.hide()
	menu_container.show()

func _on_quit_button_pressed() -> void:
	get_tree().quit()

# Option handlers
func _load_settings() -> void:
	fullscreen_check.button_pressed = Global.is_fullscreen
	volume_slider.value = Global.volume_level
	graphics_option.selected = Global.graphics_quality
	
	# Apply loaded settings on start
	_apply_fullscreen(Global.is_fullscreen)
	_apply_volume(Global.volume_level)
	_apply_graphics(Global.graphics_quality)

func _on_fullscreen_toggled(button_pressed: bool) -> void:
	Global.is_fullscreen = button_pressed
	_apply_fullscreen(button_pressed)

func _apply_fullscreen(is_fs: bool) -> void:
	if is_fs:
		DisplayServer.window_set_mode(DisplayServer.WINDOW_MODE_EXCLUSIVE_FULLSCREEN)
	else:
		DisplayServer.window_set_mode(DisplayServer.WINDOW_MODE_WINDOWED)

func _on_volume_changed(value: float) -> void:
	Global.volume_level = value
	_apply_volume(value)

func _apply_volume(value: float) -> void:
	var bus_index = AudioServer.get_bus_index("Master")
	if bus_index != -1:
		if value <= 0.0:
			AudioServer.set_bus_mute(bus_index, true)
		else:
			AudioServer.set_bus_mute(bus_index, false)
			var volume_db = linear_to_db(value / 100.0)
			AudioServer.set_bus_volume_db(bus_index, volume_db)

func _on_graphics_selected(index: int) -> void:
	Global.graphics_quality = index
	_apply_graphics(index)

func _apply_graphics(index: int) -> void:
	match index:
		0: # Baixo
			DisplayServer.window_set_vsync_mode(DisplayServer.VSYNC_DISABLED)
			get_viewport().msaa_2d = Viewport.MSAA_DISABLED
			Engine.max_fps = 30
		1: # Médio
			DisplayServer.window_set_vsync_mode(DisplayServer.VSYNC_ENABLED)
			get_viewport().msaa_2d = Viewport.MSAA_2X
			Engine.max_fps = 60
		2: # Alto
			DisplayServer.window_set_vsync_mode(DisplayServer.VSYNC_ENABLED)
			get_viewport().msaa_2d = Viewport.MSAA_4X
			Engine.max_fps = 0 # uncapped

func _on_load_game_pressed() -> void:
	var data = Global.load_game()
	if not data.is_empty():
		Global.sword_collected = data.get("sword_collected", false)
		Global.equipped_weapon = data.get("equipped_weapon", "fists")
		Global.set("loaded_lives", data.get("lives", 3))
		Global.set("should_apply_loaded_lives", true)
		
		var scene_path = data.get("level", "res://Floresta.tscn")
		get_tree().change_scene_to_file(scene_path)
