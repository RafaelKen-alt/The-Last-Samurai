extends Camera2D

@onready var target: Node2D = null

@export var lerp_speed: float = 8.0
@export var shake_decay: float = 5.0

var shake_strength: float = 0.0
var rng = RandomNumberGenerator.new()

func _ready():
	rng.randomize()
	Global.camera = self
	
	target = get_tree().get_first_node_in_group("player")
	if target:
		# Set initial position immediately to avoid a start-up lerp jump
		global_position = target.global_position

func _process(delta):
	if target:
		# Smoothly slide camera to target (with a slight upward offset for better visibility)
		var target_pos = target.global_position
		target_pos.y -= 25.0
		global_position = global_position.lerp(target_pos, lerp_speed * delta)
	else:
		# Try to locate player again if lost/respawned
		target = get_tree().get_first_node_in_group("player")

	# Screen Shake logic
	if shake_strength > 0.05:
		shake_strength = move_toward(shake_strength, 0.0, shake_decay * delta)
		offset = Vector2(
			rng.randf_range(-shake_strength, shake_strength),
			rng.randf_range(-shake_strength, shake_strength)
		)
	else:
		offset = Vector2.ZERO

func shake(strength: float) -> void:
	shake_strength = max(shake_strength, strength)

