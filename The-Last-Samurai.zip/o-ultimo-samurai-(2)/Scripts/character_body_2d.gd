extends CharacterBody2D

@onready var anim: AnimatedSprite2D = $AnimatedSprite2D

@onready var attack_hitbox_right: Area2D = $AttackHitboxRight
@onready var attack_shape_right: CollisionShape2D = $AttackHitboxRight/CollisionShape2D

@onready var attack_hitbox_left: Area2D = $AttackHitboxLeft
@onready var attack_shape_left: CollisionShape2D = $AttackHitboxLeft/CollisionShape2D

@onready var hurt_timer: Timer = $HurtTimer
@onready var death_timer: Timer = $DeathTimer

@export var SPEED := 200.0
@export var RUN_SPEED := 350.0
@export var JUMP_VELOCITY := -500.0
@export var death_y := 1000.0

@export var max_health := 100
@export var health := 100

@export var attack1_damage := 10
@export var attack2_damage := 15
@export var attack3_damage := 25
@export var hurt_duration := 0.35
@export var death_duration := 0.5

@export var sword_bonus_damage := 0

var is_attacking := false
var is_hurt := false
var is_dead := false
var is_defending := false
var queued_next_attack := false
var current_attack_damage := 0
var already_hit := []
var facing := 1
var has_sword := false

# Defensive & UI variables
var protect_press_time := 0.0
var hud: CanvasLayer = null
var health_bar: ProgressBar = null
var damage_bonus_label: Label = null
var hotbar_layout: HBoxContainer = null
var slot_fists_label: Label = null
var slot_sword_label: Label = null
var inventory_panel: PanelContainer = null
var is_inventory_open := false

# Sistema de Vidas / Tentativas
var lives := 3
var last_safe_position := Vector2.ZERO
var lives_label: Label = null

# Variavel de pulo duplo
var jump_count := 0

func _ready() -> void:
	health = max_health
	last_safe_position = global_position
	print("PLAYER OK")

	add_to_group("player")

	collision_layer = 2
	collision_mask = 1

	if Global.sword_collected:
		if Global.equipped_weapon == "sword":
			has_sword = true
			sword_bonus_damage = Global.sword_bonus_damage
		else:
			has_sword = false
			sword_bonus_damage = 0
	else:
		has_sword = false
		sword_bonus_damage = 0

	if Global.get("should_apply_loaded_lives"):
		lives = Global.get("loaded_lives")
		Global.set("should_apply_loaded_lives", false)

	anim.animation_finished.connect(_on_animation_finished)

	attack_hitbox_right.body_entered.connect(_on_attack_hitbox_body_entered)
	attack_hitbox_left.body_entered.connect(_on_attack_hitbox_body_entered)

	hurt_timer.timeout.connect(_on_hurt_timer_timeout)
	death_timer.timeout.connect(_on_death_timer_timeout)

	hurt_timer.one_shot = true
	death_timer.one_shot = true

	attack_hitbox_right.monitoring = true
	attack_hitbox_right.monitorable = true
	attack_hitbox_right.collision_layer = 4
	attack_hitbox_right.collision_mask = 3

	attack_hitbox_left.monitoring = true
	attack_hitbox_left.monitorable = true
	attack_hitbox_left.collision_layer = 4
	attack_hitbox_left.collision_mask = 3

	_disable_all_hitboxes()

	if anim.sprite_frames.has_animation("idle"):
		anim.play("idle")
		
	# Instanciar HUD e Clima
	_setup_hud()
	_spawn_ambient_particles.call_deferred()

func _physics_process(delta: float) -> void:
	if is_on_floor() and not is_dead and not is_hurt:
		last_safe_position = global_position

	if global_position.y > death_y and not is_dead:
		health = 0
		die()
		return

	if is_dead:
		velocity.x = 0
		move_and_slide()
		return

	if not is_on_floor():
		velocity += get_gravity() * delta

	if is_hurt:
		velocity.x = 0
		move_and_slide()
		return

	var direction := Input.get_axis("left", "right")
	var run_pressed := Input.is_action_pressed("run")
	
	# Registar início do bloqueio para o Parry
	if Input.is_action_just_pressed("protect"):
		protect_press_time = Time.get_ticks_msec() / 1000.0
		
	is_defending = Input.is_action_pressed("protect")
	var current_speed = RUN_SPEED if run_pressed else SPEED

	if direction > 0:
		facing = 1
		anim.flip_h = false
	elif direction < 0:
		facing = -1
		anim.flip_h = true

	if is_on_floor():
		jump_count = 0

	if Input.is_action_just_pressed("jump") and not is_attacking and not is_defending:
		if is_on_floor():
			velocity.y = JUMP_VELOCITY
			jump_count = 1
		elif jump_count < 2:
			velocity.y = JUMP_VELOCITY * 0.95 # Segundo pulo ligeiramente mais suave
			jump_count += 1

	if Input.is_action_just_pressed("M1") and not is_defending:
		if not is_attacking:
			_start_attack("Attack1")
		elif anim.animation == "Attack1" and not queued_next_attack:
			queued_next_attack = true
		elif anim.animation == "Attack2" and not queued_next_attack:
			queued_next_attack = true

	if is_attacking:
		velocity.x = 0

	elif is_defending:
		velocity.x = 0
		if anim.sprite_frames.has_animation("protect"):
			anim.play("protect")

	elif not is_on_floor():
		# Movimento no ar com drift controlado
		if direction != 0:
			velocity.x = move_toward(velocity.x, direction * current_speed, 1200.0 * delta)
		else:
			velocity.x = move_toward(velocity.x, 0.0, 700.0 * delta)
			
		if anim.sprite_frames.has_animation("jump"):
			anim.play("jump")

	elif direction != 0:
		# Aceleração rápida no chão para melhor resposta
		velocity.x = move_toward(velocity.x, direction * current_speed, 2200.0 * delta)
		if run_pressed and anim.sprite_frames.has_animation("run"):
			anim.play("run")
		elif anim.sprite_frames.has_animation("walk"):
			anim.play("walk")

	else:
		# Fricção rápida ao soltar os botões para não deslizar
		velocity.x = move_toward(velocity.x, 0.0, 2600.0 * delta)
		if anim.sprite_frames.has_animation("idle"):
			anim.play("idle")

	move_and_slide()

func _start_attack(anim_name: String) -> void:
	if is_dead or is_hurt:
		return

	if not anim.sprite_frames.has_animation(anim_name):
		return

	is_attacking = true
	queued_next_attack = false
	already_hit.clear()
	velocity.x = 0

	anim.stop()
	anim.frame = 0

	match anim_name:
		"Attack1":
			current_attack_damage = attack1_damage + sword_bonus_damage
		"Attack2":
			current_attack_damage = attack2_damage + sword_bonus_damage
		"Attack3":
			current_attack_damage = attack3_damage + sword_bonus_damage
		_:
			current_attack_damage = attack1_damage + sword_bonus_damage

	anim.play(anim_name)
	_enable_current_hitbox()

func _enable_current_hitbox() -> void:
	_disable_all_hitboxes()

	if facing == 1:
		attack_shape_right.disabled = false
	else:
		attack_shape_left.disabled = false

func _disable_all_hitboxes() -> void:
	attack_shape_right.disabled = true
	attack_shape_left.disabled = true

func _on_attack_hitbox_body_entered(body: Node) -> void:
	if body == self:
		return

	if body in already_hit:
		return

	if body.has_method("take_damage"):
		# Pass self as the attacker
		body.take_damage(current_attack_damage, self)
		already_hit.append(body)

func _on_animation_finished() -> void:
	if anim.animation == "Attack1":
		_disable_all_hitboxes()
		if queued_next_attack:
			_start_attack("Attack2")
		else:
			_end_attack()

	elif anim.animation == "Attack2":
		_disable_all_hitboxes()
		if queued_next_attack:
			_start_attack("Attack3")
		else:
			_end_attack()

	elif anim.animation == "Attack3":
		_disable_all_hitboxes()
		_end_attack()

	elif anim.animation == "Hurt":
		is_hurt = false
		if health > 0 and anim.sprite_frames.has_animation("idle"):
			anim.play("idle")

	elif anim.animation == "Death":
		queue_free()

func _end_attack() -> void:
	is_attacking = false
	queued_next_attack = false
	current_attack_damage = 0
	already_hit.clear()
	_disable_all_hitboxes()

	if not is_hurt and not is_dead and anim.sprite_frames.has_animation("idle"):
		anim.play("idle")

func take_damage(amount: int, attacker: Node2D = null) -> void:
	if is_dead:
		return

	# Lógica de Bloqueio e Parry
	if is_defending:
		var current_time := Time.get_ticks_msec() / 1000.0
		var time_since_press := current_time - protect_press_time
		
		if time_since_press < 0.2:
			# Parry Bem-Sucedido!
			print("PARRY! Inimigo atordoado!")
			if attacker and attacker.has_method("stun"):
				attacker.stun(2.0)
			
			Global.spawn_damage_number(0, global_position, true)
			Global.trigger_hitstop(0.15)
			if Global.camera:
				Global.camera.shake(8.0)
			Global.spawn_hit_sparks(global_position + Vector2(facing * 25.0, -15.0))
			
			# Flash ciano indicando parry
			var p_tween = create_tween()
			p_tween.tween_property(anim, "modulate", Color(0.2, 1.0, 1.0, 1.0), 0.08)
			p_tween.tween_property(anim, "modulate", Color(1.0, 1.0, 1.0, 1.0), 0.08)
			return
		else:
			# Bloqueio Normal
			print("BLOQUEIO! Dano reduzido.")
			var reduced_damage := int(amount * 0.2)
			health -= reduced_damage
			health = max(health, 0)
			_update_hud()
			
			Global.spawn_damage_number(reduced_damage, global_position)
			if Global.camera:
				Global.camera.shake(2.0)
			Global.spawn_hit_sparks(global_position + Vector2(facing * 20.0, -15.0))
			
			# Flash amarelo indicando bloqueio
			var b_tween = create_tween()
			b_tween.tween_property(anim, "modulate", Color(1.0, 1.0, 0.2, 1.0), 0.08)
			b_tween.tween_property(anim, "modulate", Color(1.0, 1.0, 1.0, 1.0), 0.08)
			
			if health <= 0:
				die()
			return

	# Dano Normal
	health -= amount
	health = max(health, 0)
	print("Vida do player: ", health)
	_update_hud()

	Global.spawn_damage_number(amount, global_position)
	if Global.camera:
		Global.camera.shake(6.0)
		
	Global.trigger_hitstop(0.08)
	_flash_white()
	Global.spawn_hit_sparks(global_position + Vector2(0.0, -20.0))

	if health <= 0:
		die()
		return

	is_hurt = true
	is_attacking = false
	queued_next_attack = false
	velocity.x = 0
	_disable_all_hitboxes()

	if anim.sprite_frames.has_animation("Hurt"):
		anim.play("Hurt")

	hurt_timer.start(hurt_duration)

func heal(amount: int) -> void:
	if is_dead:
		return

	health += amount
	health = min(health, max_health)
	print("Vida do player: ", health)
	_update_hud()

func die() -> void:
	if is_dead:
		return

	is_dead = true
	is_hurt = false
	is_attacking = false
	queued_next_attack = false
	is_defending = false
	velocity = Vector2.ZERO
	_disable_all_hitboxes()

	if anim.sprite_frames.has_animation("Death"):
		anim.play("Death")
	else:
		queue_free()

	death_timer.start(death_duration)

func _on_hurt_timer_timeout() -> void:
	is_hurt = false

	if is_dead:
		return

	anim.stop()

	if not is_on_floor() and anim.sprite_frames.has_animation("jump"):
		anim.play("jump")
	elif abs(velocity.x) > 0.1 and anim.sprite_frames.has_animation("walk"):
		anim.play("walk")
	elif anim.sprite_frames.has_animation("idle"):
		anim.play("idle")

func _on_death_timer_timeout() -> void:
	show_death_screen()

func is_defending_now() -> bool:
	return is_defending

func add_sword_to_inventory() -> void:
	show_notification("Katana recolhida! Prime [2] ou [I] para equipar.")
	_update_hud()

# --- Sistemas Adicionados para Juice & Polimento ---

# Efeito de Flash Branco ao receber dano
func _flash_white() -> void:
	var tween = create_tween()
	tween.tween_property(anim, "modulate", Color(5.0, 5.0, 5.0, 1.0), 0.08)
	tween.tween_property(anim, "modulate", Color(1.0, 1.0, 1.0, 1.0), 0.08)

# Criação dinâmica e estilização do HUD
func _setup_hud() -> void:
	hud = CanvasLayer.new()
	add_child(hud)
	
	var hud_container := MarginContainer.new()
	hud_container.set_anchors_and_offsets_preset(Control.PRESET_TOP_LEFT)
	hud_container.add_theme_constant_override("margin_left", 20)
	hud_container.add_theme_constant_override("margin_top", 20)
	hud.add_child(hud_container)
	
	var vbox := VBoxContainer.new()
	hud_container.add_child(vbox)
	
	var hb_layout := HBoxContainer.new()
	vbox.add_child(hb_layout)
	
	var hp_label := Label.new()
	hp_label.text = "HP "
	hp_label.add_theme_color_override("font_outline_color", Color(0, 0, 0))
	hp_label.add_theme_constant_override("outline_size", 4)
	hp_label.add_theme_font_size_override("font_size", 18)
	hb_layout.add_child(hp_label)
	
	health_bar = ProgressBar.new()
	health_bar.max_value = max_health
	health_bar.value = health
	health_bar.show_percentage = false
	health_bar.custom_minimum_size = Vector2(240, 18)
	
	var style_bg := StyleBoxFlat.new()
	style_bg.bg_color = Color(0.1, 0.1, 0.1, 0.6)
	style_bg.corner_radius_top_left = 3
	style_bg.corner_radius_top_right = 3
	style_bg.corner_radius_bottom_left = 3
	style_bg.corner_radius_bottom_right = 3
	
	var style_fg := StyleBoxFlat.new()
	style_fg.bg_color = Color(0.85, 0.15, 0.15) # Vermelho Samurai
	style_fg.corner_radius_top_left = 3
	style_fg.corner_radius_top_right = 3
	style_fg.corner_radius_bottom_left = 3
	style_fg.corner_radius_bottom_right = 3
	
	health_bar.add_theme_stylebox_override("background", style_bg)
	health_bar.add_theme_stylebox_override("fill", style_fg)
	hb_layout.add_child(health_bar)
	
	# Espaço em branco antes das vidas
	var spacer := Control.new()
	spacer.custom_minimum_size = Vector2(15, 0)
	hb_layout.add_child(spacer)
	
	lives_label = Label.new()
	lives_label.add_theme_color_override("font_outline_color", Color(0, 0, 0))
	lives_label.add_theme_constant_override("outline_size", 4)
	lives_label.add_theme_font_size_override("font_size", 15)
	hb_layout.add_child(lives_label)
	
	var info_layout := HBoxContainer.new()
	vbox.add_child(info_layout)
	
	damage_bonus_label = Label.new()
	damage_bonus_label.add_theme_color_override("font_outline_color", Color(0, 0, 0))
	damage_bonus_label.add_theme_constant_override("outline_size", 4)
	damage_bonus_label.add_theme_font_size_override("font_size", 14)
	info_layout.add_child(damage_bonus_label)
	
	# Mini-hotbar rápida no HUD
	hotbar_layout = HBoxContainer.new()
	hotbar_layout.add_theme_constant_override("separation", 10)
	vbox.add_child(hotbar_layout)
	
	slot_fists_label = Label.new()
	slot_fists_label.add_theme_color_override("font_outline_color", Color(0, 0, 0))
	slot_fists_label.add_theme_constant_override("outline_size", 4)
	slot_fists_label.add_theme_font_size_override("font_size", 12)
	hotbar_layout.add_child(slot_fists_label)
	
	slot_sword_label = Label.new()
	slot_sword_label.add_theme_color_override("font_outline_color", Color(0, 0, 0))
	slot_sword_label.add_theme_constant_override("outline_size", 4)
	slot_sword_label.add_theme_font_size_override("font_size", 12)
	hotbar_layout.add_child(slot_sword_label)
	
	_update_hud()

# Atualização dos elementos do HUD
func _update_hud() -> void:
	if health_bar:
		health_bar.value = health
	if lives_label:
		var hearts = ""
		for i in range(lives):
			hearts += "❤️"
		if hearts == "":
			hearts = "Nenhuma"
		lives_label.text = " |  Tentativas: " + hearts
		lives_label.add_theme_color_override("font_color", Color(1.0, 0.4, 0.4) if lives > 0 else Color(0.5, 0.5, 0.5))
	if damage_bonus_label:
		if has_sword:
			damage_bonus_label.text = "Katana Equipada (+%d Dano) | [I] Inventário" % sword_bonus_damage
			damage_bonus_label.add_theme_color_override("font_color", Color(0.4, 1.0, 0.4))
		else:
			damage_bonus_label.text = "Punhos Vazios | [I] Inventário"
			damage_bonus_label.add_theme_color_override("font_color", Color(0.75, 0.75, 0.75))
			
	if slot_fists_label and slot_sword_label:
		if not has_sword:
			slot_fists_label.text = "[1] Punhos ⭐"
			slot_fists_label.add_theme_color_override("font_color", Color(1.0, 0.85, 0.2)) # Active Golden
		else:
			slot_fists_label.text = "[1] Punhos"
			slot_fists_label.add_theme_color_override("font_color", Color(0.6, 0.6, 0.6))
			
		if not Global.sword_collected:
			slot_sword_label.text = "[2] 🔒"
			slot_sword_label.add_theme_color_override("font_color", Color(0.4, 0.4, 0.4))
		else:
			if has_sword:
				slot_sword_label.text = "[2] Katana ⭐"
				slot_sword_label.add_theme_color_override("font_color", Color(1.0, 0.85, 0.2)) # Active Golden
			else:
				slot_sword_label.text = "[2] Katana"
				slot_sword_label.add_theme_color_override("font_color", Color(0.8, 0.8, 0.8))

# Detecção do nível e carregamento de clima dinâmico
func _spawn_ambient_particles() -> void:
	if not get_tree() or not get_tree().current_scene:
		return
		
	var scene_name = get_tree().current_scene.name.to_lower()
	if scene_name == "floresta":
		_spawn_forest_particles()
	elif scene_name == "porto":
		_spawn_porto_particles()
	elif scene_name.contains("nivel3") or scene_name.contains("nivel_3") or scene_name.contains("nivel 3"):
		_spawn_forest_particles()
		_spawn_porto_particles()

# Nível 1: Queda de folhas
func _spawn_forest_particles() -> void:
	var leaves = CPUParticles2D.new()
	leaves.name = "AmbientLeaves"
	leaves.position = Vector2(1400.0, -80.0) # Centralizado no nível
	leaves.amount = 50
	leaves.lifetime = 10.0
	leaves.preprocess = 8.0
	
	leaves.emission_shape = CPUParticles2D.EMISSION_SHAPE_RECTANGLE
	leaves.emission_rect_extents = Vector2(1500.0, 10.0)
	
	leaves.direction = Vector2(0.4, 1.0)
	leaves.spread = 20.0
	leaves.gravity = Vector2(0.0, 15.0)
	leaves.initial_velocity_min = 20.0
	leaves.initial_velocity_max = 50.0
	
	leaves.angular_velocity_min = 20.0
	leaves.angular_velocity_max = 90.0
	
	leaves.scale_amount_min = 3.0
	leaves.scale_amount_max = 7.0
	leaves.color = Color(0.35, 0.6, 0.15, 0.75) # Verde floresta translúcido
	
	get_tree().current_scene.add_child(leaves)

# Nível 2: Chuva em ângulo
func _spawn_porto_particles() -> void:
	var rain = CPUParticles2D.new()
	rain.name = "AmbientRain"
	rain.position = Vector2(1500.0, -100.0)
	rain.amount = 250
	rain.lifetime = 3.0
	rain.preprocess = 5.0
	
	rain.emission_shape = CPUParticles2D.EMISSION_SHAPE_RECTANGLE
	rain.emission_rect_extents = Vector2(2000.0, 10.0)
	
	rain.direction = Vector2(-0.25, 1.0)
	rain.spread = 4.0
	rain.gravity = Vector2(0.0, 400.0) # Chuva rápida
	rain.initial_velocity_min = 250.0
	rain.initial_velocity_max = 450.0
	
	rain.scale_amount_min = 1.0
	rain.scale_amount_max = 2.5
	rain.color = Color(0.55, 0.65, 0.85, 0.35) # Azul acinzentado e transparente
	
	get_tree().current_scene.add_child(rain)

# --- Sistema de Inventário (Premium) ---

func _unhandled_input(event: InputEvent) -> void:
	if is_dead:
		return
	if event is InputEventKey and event.pressed and not event.echo:
		if event.keycode == KEY_I:
			toggle_inventory()
		elif event.keycode == KEY_1:
			equip_weapon("fists")
		elif event.keycode == KEY_2:
			if Global.sword_collected:
				equip_weapon("sword")
			else:
				show_notification("Katana ainda não foi encontrada!")

func toggle_inventory() -> void:
	is_inventory_open = !is_inventory_open
	if is_inventory_open:
		open_inventory()
	else:
		close_inventory()

func open_inventory() -> void:
	if not inventory_panel:
		_build_inventory_ui()
	_update_inventory_ui()
	inventory_panel.show()
	get_tree().paused = true
	Input.mouse_mode = Input.MOUSE_MODE_VISIBLE

func close_inventory() -> void:
	if inventory_panel:
		inventory_panel.hide()
	is_inventory_open = false
	get_tree().paused = false
	Input.mouse_mode = Input.MOUSE_MODE_CAPTURED

func _build_inventory_ui() -> void:
	if not hud:
		_setup_hud()
		
	inventory_panel = PanelContainer.new()
	inventory_panel.process_mode = Node.PROCESS_MODE_ALWAYS
	
	var style_panel := StyleBoxFlat.new()
	style_panel.bg_color = Color(0.08, 0.08, 0.12, 0.95)
	style_panel.border_width_left = 3
	style_panel.border_width_top = 3
	style_panel.border_width_right = 3
	style_panel.border_width_bottom = 3
	style_panel.border_color = Color(0.85, 0.15, 0.15) # Vermelho Samurai
	style_panel.corner_radius_top_left = 12
	style_panel.corner_radius_top_right = 12
	style_panel.corner_radius_bottom_left = 12
	style_panel.corner_radius_bottom_right = 12
	style_panel.content_margin_left = 25
	style_panel.content_margin_top = 25
	style_panel.content_margin_right = 25
	style_panel.content_margin_bottom = 25
	inventory_panel.add_theme_stylebox_override("panel", style_panel)
	
	inventory_panel.custom_minimum_size = Vector2(480, 320)
	inventory_panel.anchors_preset = Control.PRESET_CENTER
	inventory_panel.set_anchors_and_offsets_preset(Control.PRESET_CENTER)
	
	hud.add_child(inventory_panel)
	
	var vbox := VBoxContainer.new()
	vbox.add_theme_constant_override("separation", 20)
	inventory_panel.add_child(vbox)
	
	var title := Label.new()
	title.text = "INVENTÁRIO DO SAMURAI"
	title.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	title.add_theme_color_override("font_color", Color(1.0, 0.85, 0.2)) # Golden
	title.add_theme_font_size_override("font_size", 22)
	title.add_theme_color_override("font_outline_color", Color(0, 0, 0))
	title.add_theme_constant_override("outline_size", 4)
	vbox.add_child(title)
	
	var sep := HSeparator.new()
	vbox.add_child(sep)
	
	var item_hbox := HBoxContainer.new()
	item_hbox.alignment = BoxContainer.ALIGNMENT_CENTER
	item_hbox.add_theme_constant_override("separation", 30)
	vbox.add_child(item_hbox)
	
	# Slot 1: Punhos
	var slot_fists := PanelContainer.new()
	slot_fists.custom_minimum_size = Vector2(180, 160)
	var style_slot_f := StyleBoxFlat.new()
	style_slot_f.bg_color = Color(0.15, 0.15, 0.18, 0.8)
	style_slot_f.border_width_left = 2
	style_slot_f.border_width_top = 2
	style_slot_f.border_width_right = 2
	style_slot_f.border_width_bottom = 2
	style_slot_f.corner_radius_top_left = 8
	style_slot_f.corner_radius_top_right = 8
	style_slot_f.corner_radius_bottom_left = 8
	style_slot_f.corner_radius_bottom_right = 8
	slot_fists.add_theme_stylebox_override("panel", style_slot_f)
	item_hbox.add_child(slot_fists)
	
	var v_fists := VBoxContainer.new()
	v_fists.alignment = BoxContainer.ALIGNMENT_CENTER
	v_fists.add_theme_constant_override("separation", 10)
	slot_fists.add_child(v_fists)
	
	var fist_title := Label.new()
	fist_title.text = "👊 Punhos"
	fist_title.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	fist_title.add_theme_font_size_override("font_size", 16)
	v_fists.add_child(fist_title)
	
	var fist_desc := Label.new()
	fist_desc.text = "Combate Básico\nDano Padrão"
	fist_desc.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	fist_desc.add_theme_color_override("font_color", Color(0.65, 0.65, 0.65))
	fist_desc.add_theme_font_size_override("font_size", 12)
	v_fists.add_child(fist_desc)
	
	var equip_fists_btn := Button.new()
	equip_fists_btn.text = "Equipar [1]"
	equip_fists_btn.pressed.connect(func(): equip_weapon("fists"))
	v_fists.add_child(equip_fists_btn)
	
	# Slot 2: Espada
	var slot_sword := PanelContainer.new()
	slot_sword.custom_minimum_size = Vector2(180, 160)
	var style_slot_s := StyleBoxFlat.new()
	style_slot_s.bg_color = Color(0.15, 0.15, 0.18, 0.8)
	style_slot_s.border_width_left = 2
	style_slot_s.border_width_top = 2
	style_slot_s.border_width_right = 2
	style_slot_s.border_width_bottom = 2
	style_slot_s.corner_radius_top_left = 8
	style_slot_s.corner_radius_top_right = 8
	style_slot_s.corner_radius_bottom_left = 8
	style_slot_s.corner_radius_bottom_right = 8
	slot_sword.add_theme_stylebox_override("panel", style_slot_s)
	item_hbox.add_child(slot_sword)
	
	var v_sword := VBoxContainer.new()
	v_sword.alignment = BoxContainer.ALIGNMENT_CENTER
	v_sword.add_theme_constant_override("separation", 10)
	slot_sword.add_child(v_sword)
	
	var sword_title := Label.new()
	sword_title.text = "⚔️ Katana"
	sword_title.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	sword_title.add_theme_font_size_override("font_size", 16)
	v_sword.add_child(sword_title)
	
	var sword_desc := Label.new()
	sword_desc.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	sword_desc.add_theme_font_size_override("font_size", 12)
	v_sword.add_child(sword_desc)
	
	var equip_sword_btn := Button.new()
	equip_sword_btn.pressed.connect(func(): equip_weapon("sword"))
	v_sword.add_child(equip_sword_btn)
	
	var footer := Label.new()
	footer.text = "Pressiona [I] para Fechar | Usa [1] / [2] para alternar rapidamente"
	footer.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	footer.add_theme_color_override("font_color", Color(0.5, 0.5, 0.5))
	footer.add_theme_font_size_override("font_size", 11)
	vbox.add_child(footer)
	
	self.set_meta("slot_fists_style", style_slot_f)
	self.set_meta("slot_sword_style", style_slot_s)
	self.set_meta("equip_fists_btn", equip_fists_btn)
	self.set_meta("equip_sword_btn", equip_sword_btn)
	self.set_meta("sword_desc", sword_desc)

func _update_inventory_ui() -> void:
	if not inventory_panel:
		return
		
	var style_slot_f: StyleBoxFlat = self.get_meta("slot_fists_style")
	var style_slot_s: StyleBoxFlat = self.get_meta("slot_sword_style")
	var btn_f: Button = self.get_meta("equip_fists_btn")
	var btn_s: Button = self.get_meta("equip_sword_btn")
	var desc_s: Label = self.get_meta("sword_desc")
	
	if not has_sword:
		style_slot_f.border_color = Color(1.0, 0.85, 0.2) # Active golden
		btn_f.text = "Equipado"
		btn_f.disabled = true
	else:
		style_slot_f.border_color = Color(0.4, 0.4, 0.4)
		btn_f.text = "Equipar [1]"
		btn_f.disabled = false
		
	if not Global.sword_collected:
		style_slot_s.border_color = Color(0.25, 0.25, 0.25)
		style_slot_s.bg_color = Color(0.08, 0.08, 0.1, 0.8)
		desc_s.text = "🔒 Bloqueado\nEncontra no mapa"
		desc_s.add_theme_color_override("font_color", Color(0.4, 0.4, 0.4))
		btn_s.text = "Bloqueado"
		btn_s.disabled = true
	else:
		style_slot_s.bg_color = Color(0.15, 0.15, 0.18, 0.8)
		desc_s.text = "+15 Dano Bónus\nCorte Rápido"
		desc_s.add_theme_color_override("font_color", Color(0.4, 1.0, 0.4)) # Green text
		if has_sword:
			style_slot_s.border_color = Color(1.0, 0.85, 0.2) # Active golden
			btn_s.text = "Equipado"
			btn_s.disabled = true
		else:
			style_slot_s.border_color = Color(0.4, 0.4, 0.4)
			btn_s.text = "Equipar [2]"
			btn_s.disabled = false

func equip_weapon(weapon_name: String) -> void:
	if weapon_name == "fists":
		has_sword = false
		sword_bonus_damage = 0
		Global.equipped_weapon = "fists"
		show_notification("Punhos Equipados!")
	elif weapon_name == "sword" and Global.sword_collected:
		has_sword = true
		sword_bonus_damage = Global.sword_bonus_damage
		Global.equipped_weapon = "sword"
		show_notification("Katana Equipada!")
		
	_update_hud()
	_update_inventory_ui()

func show_notification(text: String) -> void:
	if not hud:
		return
	var banner := Label.new()
	banner.text = text
	banner.add_theme_color_override("font_color", Color(1.0, 0.9, 0.3)) # Golden text
	banner.add_theme_color_override("font_outline_color", Color(0, 0, 0))
	banner.add_theme_constant_override("outline_size", 5)
	banner.add_theme_font_size_override("font_size", 16)
	banner.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	
	# Position at top center
	banner.anchors_preset = Control.PRESET_CENTER_TOP
	banner.set_anchors_and_offsets_preset(Control.PRESET_CENTER_TOP)
	banner.position.y += 120
	
	hud.add_child(banner)
	
	# Animate float and fade
	var tween := banner.create_tween().set_parallel(true)
	tween.tween_property(banner, "position:y", banner.position.y - 45.0, 2.0).set_trans(Tween.TRANS_CUBIC).set_ease(Tween.EASE_OUT)
	tween.tween_property(banner, "modulate:a", 0.0, 0.8).set_delay(1.2)
	tween.chain().tween_callback(banner.queue_free)

func show_victory_screen() -> void:
	if not hud:
		_setup_hud()
		
	var victory_panel := PanelContainer.new()
	victory_panel.process_mode = Node.PROCESS_MODE_ALWAYS
	
	var style_panel := StyleBoxFlat.new()
	style_panel.bg_color = Color(0.05, 0.05, 0.08, 0.95)
	style_panel.border_width_left = 4
	style_panel.border_width_top = 4
	style_panel.border_width_right = 4
	style_panel.border_width_bottom = 4
	style_panel.border_color = Color(1.0, 0.85, 0.2) # Golden border for victory
	style_panel.corner_radius_top_left = 15
	style_panel.corner_radius_top_right = 15
	style_panel.corner_radius_bottom_left = 15
	style_panel.corner_radius_bottom_right = 15
	style_panel.content_margin_left = 35
	style_panel.content_margin_top = 35
	style_panel.content_margin_right = 35
	style_panel.content_margin_bottom = 35
	victory_panel.add_theme_stylebox_override("panel", style_panel)
	
	victory_panel.custom_minimum_size = Vector2(500, 320)
	victory_panel.anchors_preset = Control.PRESET_CENTER
	victory_panel.set_anchors_and_offsets_preset(Control.PRESET_CENTER)
	
	hud.add_child(victory_panel)
	
	var vbox := VBoxContainer.new()
	vbox.add_theme_constant_override("separation", 25)
	vbox.alignment = BoxContainer.ALIGNMENT_CENTER
	victory_panel.add_child(vbox)
	
	# Main Title
	var title := Label.new()
	title.text = "YOU WIN!"
	title.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	title.add_theme_color_override("font_color", Color(1.0, 0.85, 0.2)) # Golden
	title.add_theme_font_size_override("font_size", 42)
	title.add_theme_color_override("font_outline_color", Color(0, 0, 0))
	title.add_theme_constant_override("outline_size", 8)
	vbox.add_child(title)
	
	# Subtitle
	var subtitle := Label.new()
	subtitle.text = "Parabéns! Completaste a jornada do Último Samurai!"
	subtitle.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	subtitle.add_theme_color_override("font_color", Color(0.9, 0.9, 0.9))
	subtitle.add_theme_font_size_override("font_size", 16)
	vbox.add_child(subtitle)
	
	# Spacer
	var separator := HSeparator.new()
	vbox.add_child(separator)
	
	# Button Container
	var btn_hbox := HBoxContainer.new()
	btn_hbox.alignment = BoxContainer.ALIGNMENT_CENTER
	btn_hbox.add_theme_constant_override("separation", 20)
	vbox.add_child(btn_hbox)
	
	# Restart Button
	var restart_btn := Button.new()
	restart_btn.text = "Jogar Novamente"
	restart_btn.custom_minimum_size = Vector2(160, 45)
	restart_btn.pressed.connect(func():
		get_tree().paused = false
		Global.sword_collected = false
		Global.equipped_weapon = "fists"
		get_tree().change_scene_to_file("res://Floresta.tscn")
	)
	btn_hbox.add_child(restart_btn)
	
	# Quit Button
	var quit_btn := Button.new()
	quit_btn.text = "Sair do Jogo"
	quit_btn.custom_minimum_size = Vector2(160, 45)
	quit_btn.pressed.connect(func():
		get_tree().quit()
	)
	btn_hbox.add_child(quit_btn)
	
	# Pause game and release mouse
	get_tree().paused = true
	Input.mouse_mode = Input.MOUSE_MODE_VISIBLE

func show_death_screen() -> void:
	if not hud:
		_setup_hud()
		
	var death_panel := PanelContainer.new()
	death_panel.name = "DeathPanel"
	death_panel.process_mode = Node.PROCESS_MODE_ALWAYS
	
	var style_panel := StyleBoxFlat.new()
	style_panel.bg_color = Color(0.08, 0.02, 0.02, 0.95) # Crimson-tinged dark background
	style_panel.border_width_left = 4
	style_panel.border_width_top = 4
	style_panel.border_width_right = 4
	style_panel.border_width_bottom = 4
	style_panel.border_color = Color(0.85, 0.15, 0.15) # Crimson red border
	style_panel.corner_radius_top_left = 15
	style_panel.corner_radius_top_right = 15
	style_panel.corner_radius_bottom_left = 15
	style_panel.corner_radius_bottom_right = 15
	style_panel.content_margin_left = 35
	style_panel.content_margin_top = 35
	style_panel.content_margin_right = 35
	style_panel.content_margin_bottom = 35
	death_panel.add_theme_stylebox_override("panel", style_panel)
	
	death_panel.custom_minimum_size = Vector2(500, 320)
	death_panel.anchors_preset = Control.PRESET_CENTER
	death_panel.set_anchors_and_offsets_preset(Control.PRESET_CENTER)
	
	hud.add_child(death_panel)
	
	var vbox := VBoxContainer.new()
	vbox.add_theme_constant_override("separation", 20)
	vbox.alignment = BoxContainer.ALIGNMENT_CENTER
	death_panel.add_child(vbox)
	
	# Main Title
	var title := Label.new()
	title.text = "GAME OVER"
	title.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	title.add_theme_color_override("font_color", Color(0.85, 0.15, 0.15)) # Crimson Red
	title.add_theme_font_size_override("font_size", 42)
	title.add_theme_color_override("font_outline_color", Color(0, 0, 0))
	title.add_theme_constant_override("outline_size", 8)
	vbox.add_child(title)
	
	# Subtitle
	var subtitle := Label.new()
	if lives > 0:
		subtitle.text = "O Samurai caiu em combate. Tens mais %d tentativas." % lives
	else:
		subtitle.text = "Sem tentativas restantes! O Samurai foi derrotado."
	subtitle.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	subtitle.add_theme_color_override("font_color", Color(0.8, 0.8, 0.8))
	subtitle.add_theme_font_size_override("font_size", 16)
	vbox.add_child(subtitle)
	
	# Spacer
	var separator := HSeparator.new()
	vbox.add_child(separator)
	
	# Button Container
	var btn_hbox := HBoxContainer.new()
	btn_hbox.alignment = BoxContainer.ALIGNMENT_CENTER
	btn_hbox.add_theme_constant_override("separation", 15)
	vbox.add_child(btn_hbox)
	
	# Respawn Button (only if lives > 0)
	if lives > 0:
		var respawn_btn := Button.new()
		respawn_btn.text = "Tentar Novamente (%d)" % lives
		respawn_btn.custom_minimum_size = Vector2(170, 45)
		respawn_btn.pressed.connect(func():
			respawn_player()
		)
		btn_hbox.add_child(respawn_btn)
	
	# Restart Button
	var restart_btn := Button.new()
	restart_btn.text = "Recomeçar (Nível 1)"
	restart_btn.custom_minimum_size = Vector2(170, 45)
	restart_btn.pressed.connect(func():
		get_tree().paused = false
		Global.sword_collected = false
		Global.equipped_weapon = "fists"
		get_tree().change_scene_to_file("res://Floresta.tscn")
	)
	btn_hbox.add_child(restart_btn)
	
	# Quit Button
	var quit_btn := Button.new()
	quit_btn.text = "Sair"
	quit_btn.custom_minimum_size = Vector2(100, 45)
	quit_btn.pressed.connect(func():
		get_tree().quit()
	)
	btn_hbox.add_child(quit_btn)
	
	# Pause game and release mouse
	get_tree().paused = true
	Input.mouse_mode = Input.MOUSE_MODE_VISIBLE

func respawn_player() -> void:
	lives -= 1
	health = max_health
	is_dead = false
	is_hurt = false
	is_attacking = false
	is_defending = false
	velocity = Vector2.ZERO
	
	# Move to safety
	global_position = last_safe_position
	
	# Reset animations
	if anim.sprite_frames.has_animation("idle"):
		anim.play("idle")
		
	# Unpause
	get_tree().paused = false
	Input.mouse_mode = Input.MOUSE_MODE_CAPTURED
	
	# Clean up UI
	if hud and hud.has_node("DeathPanel"):
		hud.get_node("DeathPanel").queue_free()
	
	_update_hud()
	show_notification("Tentativa gasta! Restam %d." % lives)
