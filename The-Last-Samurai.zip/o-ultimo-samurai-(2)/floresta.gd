extends Node2D

# Pause menu toggling is now managed autonomously by the PauseMenu instance.
