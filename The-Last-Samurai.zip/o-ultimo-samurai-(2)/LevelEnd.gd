extends Area2D

@export_file("*.tscn") var next_scene_path: String

func _ready() -> void:
	print("Portal pronto")
	print("Cena definida: ", next_scene_path)

	body_entered.connect(_on_body_entered)

func _on_body_entered(body: Node2D) -> void:
	print("Entrou algo: ", body.name)

	if not body.is_in_group("player"):
		print("Não é o player")
		return

	if next_scene_path.is_empty():
		print("Path vazio")
		return

	if next_scene_path == "victory":
		if body.has_method("show_victory_screen"):
			body.show_victory_screen()
		return

	print("A mudar para: ", next_scene_path)

	get_tree().paused = false
	get_tree().call_deferred("change_scene_to_file", next_scene_path)
