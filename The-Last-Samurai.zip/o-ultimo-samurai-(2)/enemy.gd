extends CharacterBody2D

enum EnemyState {
	Walk,
	Attack1,
	Attack2,
	Attack3,
	Hurt,
	Death,
	Stun
}

@onready var anim: AnimatedSprite2D = $AnimatedSprite2D

@onready var attack_area: Area2D = $AttackArea

@onready var attack_hitbox_right: Area2D = $AttackHitboxRight
@onready var attack_shape_right: CollisionShape2D = $AttackHitboxRight/CollisionShape2D

@onready var attack_hitbox_left: Area2D = $AttackHitboxLeft
@onready var attack_shape_left: CollisionShape2D = $AttackHitboxLeft/CollisionShape2D

@onready var wall_detector: RayCast2D = $WallDetector
@onready var player_detector: RayCast2D = $PlayerDetector
@onready var ground_detector: RayCast2D = $GroundDetector

@onready var attack_cooldown: Timer = $AttackCooldown
@onready var hurt_timer: Timer = $HurtTimer
@onready var death_timer: Timer = $DeathTimer
@onready var stun_timer: Timer = $StunTimer

@export var walk_speed: float = 18.0
@export var attack_lunge_speed: float = 10.0
@export var attack_lunge_friction: float = 300.0
@export var max_health: int = 80

@export var attack1_damage: int = 8
@export var attack2_damage: int = 10
@export var attack3_damage: int = 14
@export var attack_delay: float = 1.0
@export var hurt_duration: float = 0.35
@export var death_duration: float = 0.50

@export var sprite_speed_scale: float = 0.45
@export var debug_mode: bool = true

var state: EnemyState = EnemyState.Walk

var health: int = 0
var player: Node2D = null
var player_in_attack: bool = false

var is_attacking: bool = false
var is_hurt: bool = false
var is_dead: bool = false
var can_attack: bool = true

var facing: int = 1
var current_attack_damage: int = 0
var attack_index: int = 0
var already_hit: Array[Node] = []

# Adicionados para UI e Alerta
var hp_bar: ProgressBar = null
var spotted_player := false

func _ready() -> void:
	health = max_health
	anim.speed_scale = sprite_speed_scale

	# CONFIGURAÇÃO DE MÁSCARAS DE COLISÃO PROGRAMÁTICA
	# O jogador está na camada 2.
	player_detector.collision_mask = 3 # Deteta jogador (camada 2) e mundo (camada 1)
	attack_area.collision_mask = 2 # Deteta apenas jogador (camada 2)
	attack_hitbox_right.collision_mask = 2 # Deteta jogador (camada 2)
	attack_hitbox_left.collision_mask = 2 # Deteta jogador (camada 2)

	if not attack_area.body_entered.is_connected(_on_attack_area_body_entered):
		attack_area.body_entered.connect(_on_attack_area_body_entered)

	if not attack_area.body_exited.is_connected(_on_attack_area_body_exited):
		attack_area.body_exited.connect(_on_attack_area_body_exited)

	if not attack_hitbox_right.body_entered.is_connected(_on_attack_hitbox_body_entered):
		attack_hitbox_right.body_entered.connect(_on_attack_hitbox_body_entered)

	if not attack_hitbox_left.body_entered.is_connected(_on_attack_hitbox_body_entered):
		attack_hitbox_left.body_entered.connect(_on_attack_hitbox_body_entered)

	if not attack_cooldown.timeout.is_connected(_on_attack_cooldown_timeout):
		attack_cooldown.timeout.connect(_on_attack_cooldown_timeout)

	if not hurt_timer.timeout.is_connected(_on_hurt_timer_timeout):
		hurt_timer.timeout.connect(_on_hurt_timer_timeout)

	if not death_timer.timeout.is_connected(_on_death_timer_timeout):
		death_timer.timeout.connect(_on_death_timer_timeout)
		
	if not stun_timer.timeout.is_connected(_on_stun_timer_timeout):
		stun_timer.timeout.connect(_on_stun_timer_timeout)

	if not anim.animation_finished.is_connected(_on_animation_finished):
		anim.animation_finished.connect(_on_animation_finished)

	attack_cooldown.one_shot = true
	hurt_timer.one_shot = true
	death_timer.one_shot = true
	stun_timer.one_shot = true

	attack_area.monitoring = true
	attack_hitbox_right.monitoring = true
	attack_hitbox_left.monitoring = true

	_disable_all_attack_hitboxes()
	_update_detectors_direction()
	_setup_hp_bar()

	if anim.sprite_frames.has_animation("Walk"):
		anim.play("Walk")

func _physics_process(delta: float) -> void:
	if is_dead:
		velocity.x = 0.0
		move_and_slide()
		return

	if not is_on_floor():
		velocity += get_gravity() * delta

	# Bypass do comportamento padrão quando atordoado (Stun)
	if state == EnemyState.Stun:
		velocity.x = 0.0
		move_and_slide()
		return

	if is_hurt:
		state = EnemyState.Hurt
		velocity.x = 0.0
		move_and_slide()
		return

	if is_attacking:
		_state_attack(delta)
		move_and_slide()
		return

	_update_player_from_detector()

	if player != null and is_instance_valid(player):
		if player.global_position.x > global_position.x:
			facing = 1
			anim.flip_h = false
		elif player.global_position.x < global_position.x:
			facing = -1
			anim.flip_h = true

	_update_detectors_direction()

	if player_in_attack and can_attack and player != null and is_instance_valid(player):
		velocity.x = 0.0
		_start_attack()
		move_and_slide()
		return

	_walk_state()
	move_and_slide()

func _walk_state() -> void:
	state = EnemyState.Walk

	if wall_detector.is_colliding():
		var wall_body: Object = wall_detector.get_collider()
		# Evitar que colida com o jogador e ache que é uma parede
		if wall_body == null or not (wall_body is Node and (wall_body as Node).is_in_group("player")):
			_flip_enemy()

	if not ground_detector.is_colliding():
		_flip_enemy()

	if player_detector.is_colliding():
		var body: Object = player_detector.get_collider()
		if body != null and body is Node and (body as Node).is_in_group("player"):
			player = body as Node2D
			var dir_to_player: float = sign(player.global_position.x - global_position.x)
			velocity.x = dir_to_player * walk_speed
			
			# Mostrar balão de exclamação ao avistar o jogador pela primeira vez
			if not spotted_player:
				spotted_player = true
				_show_alert_icon()

			if dir_to_player > 0.0:
				facing = 1
				anim.flip_h = false
			elif dir_to_player < 0.0:
				facing = -1
				anim.flip_h = true

			_update_detectors_direction()

			if velocity.x != 0.0 and anim.sprite_frames.has_animation("Walk") and anim.animation != "Walk":
				anim.play("Walk")
			return

	velocity.x = walk_speed * facing
	anim.flip_h = facing == -1

	if velocity.x != 0.0 and anim.sprite_frames.has_animation("Walk") and anim.animation != "Walk":
		anim.play("Walk")

func _state_attack(delta: float) -> void:
	velocity.x = move_toward(velocity.x, 0.0, attack_lunge_friction * delta)

func _flip_enemy() -> void:
	facing *= -1
	anim.flip_h = facing == -1
	_update_detectors_direction()

func _update_detectors_direction() -> void:
	var wall_target: Vector2 = wall_detector.target_position
	wall_target.x = abs(wall_target.x) * facing
	wall_detector.target_position = wall_target
	wall_detector.force_raycast_update()

	var ground_target: Vector2 = ground_detector.target_position
	ground_target.x = abs(ground_target.x) * facing
	ground_detector.target_position = ground_target
	ground_detector.force_raycast_update()

	var player_target: Vector2 = player_detector.target_position
	player_target.x = abs(player_target.x) * facing
	player_detector.target_position = player_target
	player_detector.force_raycast_update()

func _update_player_from_detector() -> void:
	if player_detector.is_colliding():
		var body: Object = player_detector.get_collider()
		if body != null and body is Node and (body as Node).is_in_group("player"):
			player = body as Node2D

func _start_attack() -> void:
	if is_dead or is_hurt or is_attacking or not can_attack or state == EnemyState.Stun:
		return

	is_attacking = true
	can_attack = false
	already_hit.clear()
	velocity.x = float(facing) * attack_lunge_speed

	attack_index += 1
	if attack_index > 3:
		attack_index = 1

	match attack_index:
		1:
			state = EnemyState.Attack1
			current_attack_damage = attack1_damage
			if anim.sprite_frames.has_animation("Attack1"):
				anim.play("Attack1")
		2:
			state = EnemyState.Attack2
			current_attack_damage = attack2_damage
			if anim.sprite_frames.has_animation("Attack2"):
				anim.play("Attack2")
		3:
			state = EnemyState.Attack3
			current_attack_damage = attack3_damage
			if anim.sprite_frames.has_animation("Attack3"):
				anim.play("Attack3")

	_enable_current_attack_hitbox()
	await get_tree().physics_frame
	_check_attack_hit_now()
	attack_cooldown.start(attack_delay)

func _enable_current_attack_hitbox() -> void:
	_disable_all_attack_hitboxes()

	if facing == 1:
		attack_shape_left.set_deferred("disabled", false)
	else:
		attack_shape_right.set_deferred("disabled", false)

func _disable_all_attack_hitboxes() -> void:
	attack_shape_right.set_deferred("disabled", true)
	attack_shape_left.set_deferred("disabled", true)

func _check_attack_hit_now() -> void:
	var bodies: Array = []

	if facing == 1:
		bodies = attack_hitbox_left.get_overlapping_bodies()
	else:
		bodies = attack_hitbox_right.get_overlapping_bodies()

	for body in bodies:
		if body == self:
			continue
		if body in already_hit:
			continue
		if not body.is_in_group("player"):
			continue

		if body.has_method("take_damage"):
			# Passar "self" como o atacante para que o jogador consiga dar Parry
			body.take_damage(current_attack_damage, self)
			already_hit.append(body)

func _on_attack_hitbox_body_entered(body: Node) -> void:
	if is_dead or state == EnemyState.Stun:
		return
	if body == self:
		return
	if body in already_hit:
		return
	if not body.is_in_group("player"):
		return

	if body.has_method("take_damage"):
		# Passar "self" como o atacante
		body.take_damage(current_attack_damage, self)
		already_hit.append(body)

func _on_animation_finished() -> void:
	if anim.animation == "Hurt":
		is_hurt = false
		state = EnemyState.Walk

		if not is_dead and anim.sprite_frames.has_animation("Walk"):
			anim.play("Walk")

	elif anim.animation == "Attack1" or anim.animation == "Attack2" or anim.animation == "Attack3":
		if not is_dead and not is_hurt and state != EnemyState.Stun:
			_end_attack()

	elif anim.animation == "Death":
		queue_free()

func _end_attack() -> void:
	is_attacking = false
	current_attack_damage = 0
	already_hit.clear()
	_disable_all_attack_hitboxes()
	velocity.x = 0.0
	state = EnemyState.Walk

	if not is_hurt and not is_dead and anim.sprite_frames.has_animation("Walk"):
		anim.play("Walk")

func take_damage(amount: int, attacker: Node2D = null) -> void:
	if is_dead:
		return

	# Combat Juice & Feedback
	Global.spawn_damage_number(amount, global_position)
	if Global.camera:
		Global.camera.shake(4.0)
	Global.trigger_hitstop(0.08)
	_flash_white()
	Global.spawn_hit_sparks(global_position + Vector2(0.0, -15.0))

	health -= amount
	health = max(health, 0)
	
	if hp_bar:
		hp_bar.value = health

	if health <= 0:
		die()
		return

	is_hurt = true
	is_attacking = false
	state = EnemyState.Hurt
	velocity.x = 0.0
	current_attack_damage = 0
	already_hit.clear()
	_disable_all_attack_hitboxes()

	if anim.sprite_frames.has_animation("Hurt"):
		anim.stop()
		anim.frame = 0
		anim.play("Hurt")

	hurt_timer.start(hurt_duration)

func die() -> void:
	if is_dead:
		return

	is_dead = true
	is_hurt = false
	is_attacking = false
	can_attack = false
	state = EnemyState.Death
	player_in_attack = false
	player = null
	velocity = Vector2.ZERO
	current_attack_damage = 0
	already_hit.clear()
	_disable_all_attack_hitboxes()

	attack_area.monitoring = false
	attack_hitbox_right.monitoring = false
	attack_hitbox_left.monitoring = false
	wall_detector.enabled = false
	player_detector.enabled = false
	ground_detector.enabled = false

	if hp_bar:
		hp_bar.hide()

	if anim.sprite_frames.has_animation("Death"):
		anim.stop()
		anim.frame = 0
		anim.play("Death")
	else:
		queue_free()

func _on_attack_cooldown_timeout() -> void:
	can_attack = true

	if player_in_attack and player != null and is_instance_valid(player) and not is_dead and not is_hurt and not is_attacking and state != EnemyState.Stun:
		_start_attack()

func _on_hurt_timer_timeout() -> void:
	if not anim.sprite_frames.has_animation("Hurt"):
		is_hurt = false
		state = EnemyState.Walk
		if anim.sprite_frames.has_animation("Walk"):
			anim.play("Walk")

func _on_death_timer_timeout() -> void:
	if is_dead and not anim.sprite_frames.has_animation("Death"):
		queue_free()

func _on_attack_area_body_entered(body: Node) -> void:
	if body.is_in_group("player"):
		player = body as Node2D
		player_in_attack = true

		if player.global_position.x > global_position.x:
			facing = 1
			anim.flip_h = false
		elif player.global_position.x < global_position.x:
			facing = -1
			anim.flip_h = true

		_update_detectors_direction()

		if can_attack and not is_dead and not is_hurt and not is_attacking and state != EnemyState.Stun:
			_start_attack()

func _on_attack_area_body_exited(body: Node) -> void:
	if body == player:
		player_in_attack = false

# --- Sistemas Adicionados para Juice & Atordoamento ---

# Função para atordoar o inimigo (acionada pelo Parry do Jogador)
func stun(duration: float) -> void:
	if is_dead:
		return
		
	state = EnemyState.Stun
	is_attacking = false
	is_hurt = false
	velocity.x = 0.0
	_disable_all_attack_hitboxes()
	
	if anim.sprite_frames.has_animation("Hurt"):
		anim.play("Hurt")
		anim.stop() # Congela a animação no frame de dor
		
	# Tint azulado para mostrar o estado atordoado
	var tween = create_tween()
	tween.tween_property(anim, "modulate", Color(0.4, 0.65, 1.0, 1.0), 0.15)
	
	stun_timer.start(duration)

func _on_stun_timer_timeout() -> void:
	if is_dead:
		return
	state = EnemyState.Walk
	
	# Restaurar coloração original
	var tween = create_tween()
	tween.tween_property(anim, "modulate", Color(1.0, 1.0, 1.0, 1.0), 0.15)
	
	if anim.sprite_frames.has_animation("Walk"):
		anim.play("Walk")

# Criar barra de vida flutuante acima da cabeça do inimigo
func _setup_hp_bar() -> void:
	hp_bar = ProgressBar.new()
	hp_bar.max_value = max_health
	hp_bar.value = health
	hp_bar.show_percentage = false
	hp_bar.custom_minimum_size = Vector2(50, 5)
	
	# Estilo minimalista escuro/vermelho
	var style_bg := StyleBoxFlat.new()
	style_bg.bg_color = Color(0.1, 0.1, 0.1, 0.6)
	
	var style_fg := StyleBoxFlat.new()
	style_fg.bg_color = Color(0.8, 0.1, 0.1) # Vermelho
	
	hp_bar.add_theme_stylebox_override("background", style_bg)
	hp_bar.add_theme_stylebox_override("fill", style_fg)
	
	hp_bar.position = Vector2(-25, -75)
	add_child(hp_bar)

# Balão de Alerta dinâmico ao avistar o jogador
func _show_alert_icon() -> void:
	var label := Label.new()
	label.text = "!"
	label.horizontal_alignment = HorizontalAlignment.HORIZONTAL_ALIGNMENT_CENTER
	label.add_theme_color_override("font_color", Color(1.0, 0.1, 0.1))
	label.add_theme_color_override("font_outline_color", Color(0, 0, 0))
	label.add_theme_constant_override("outline_size", 5)
	label.add_theme_font_size_override("font_size", 22)
	
	# Posicionar acima da cabeça
	label.position = Vector2(-8, -100)
	add_child(label)
	
	# Animação de subida e elasticidade
	var tween := label.create_tween().set_parallel(true)
	tween.tween_property(label, "position:y", label.position.y - 25.0, 0.35).set_trans(Tween.TRANS_CUBIC).set_ease(Tween.EASE_OUT)
	tween.tween_property(label, "scale", Vector2(1.4, 1.4), 0.2).set_trans(Tween.TRANS_ELASTIC).set_ease(Tween.EASE_OUT)
	
	# Apagar depois de um curto período
	var fade_tween = label.create_tween()
	fade_tween.tween_interval(0.6)
	fade_tween.tween_property(label, "modulate:a", 0.0, 0.25)
	fade_tween.tween_callback(label.queue_free)

# Flash branco ao receber dano
func _flash_white() -> void:
	var tween = create_tween()
	tween.tween_property(anim, "modulate", Color(5.0, 5.0, 5.0, 1.0), 0.08)
	tween.tween_property(anim, "modulate", Color(1.0, 1.0, 1.0, 1.0), 0.08)
