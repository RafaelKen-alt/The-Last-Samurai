extends Node2D

const GROUND_Y := 658.0
const FOREST_LIMIT_X := 2400.0

func _ready() -> void:
	# Modulate the entire level with a subtle crimson tint to create a hardcore battle atmosphere!
	self.modulate = Color(0.85, 0.7, 0.7)

	# Keep all original collisions and TileMaps from Porto.tscn!
	# We DO NOT clear StaticBody2D children, so everything has perfect collisions.
	
	# 1. Erase port tiles and decorations in the gaps and forest section
	# In Hardcore style, gaps are wider (X=350 to 400 pixels).
	var tiles := $Tiles as TileMapLayer
	if tiles:
		# Erase forest half (X < 2400)
		for x in range(0, 77):
			for y in range(-15, 40):
				tiles.erase_cell(Vector2i(x, y))
		# Erase Gap 3 (X = 3200 to 3600 -> cells 100 to 112)
		for x in range(100, 113):
			for y in range(-15, 40):
				tiles.erase_cell(Vector2i(x, y))
		# Erase Gap 4 (X = 4500 to 4900 -> cells 140 to 153)
		for x in range(140, 154):
			for y in range(-15, 40):
				tiles.erase_cell(Vector2i(x, y))
				
	var decorations := $Decorations as TileMapLayer
	if decorations:
		# Erase forest half
		for x in range(0, 77):
			for y in range(-15, 40):
				decorations.erase_cell(Vector2i(x, y))
		# Erase Gap 3
		for x in range(100, 113):
			for y in range(-15, 40):
				decorations.erase_cell(Vector2i(x, y))
		# Erase Gap 4
		for x in range(140, 154):
			for y in range(-15, 40):
				decorations.erase_cell(Vector2i(x, y))

	# 2. Create Custom Ground Segments and Platforms (Hardcore Jumps: wide gaps, small platforms!)
	var static_world := StaticBody2D.new()
	static_world.name = "CustomWorldGround"
	static_world.collision_layer = 1
	static_world.collision_mask = 0
	add_child(static_world)
	
	var add_ground_col = func(x_start: float, x_end: float, y: float):
		var col := CollisionShape2D.new()
		var shape := RectangleShape2D.new()
		shape.size = Vector2(x_end - x_start, 100.0)
		col.shape = shape
		col.global_position = Vector2((x_start + x_end) / 2.0, y + 50.0)
		static_world.add_child(col)
		
	# Segment 1 (Forest Start): X = 0 to 700 (Gap 1 is 350px wide!)
	add_ground_col.call(0.0, 700.0, GROUND_Y)
	
	# Floating Platform 1 in Gap 1: X = 845, Y = 460 (2 wooden blocks -> small & high!)
	create_custom_platform(845.0, 460.0, 2, true)
	
	# Segment 2 (Forest Middle): X = 1050 to 1800 (Gap 2 is 400px wide!)
	add_ground_col.call(1050.0, 1800.0, GROUND_Y)
	
	# Floating Platforms in Forest Middle:
	# Platform at X = 1200, Y = 460 (2 wooden blocks)
	create_custom_platform(1200.0, 460.0, 2, true)
	# Platform at X = 1480, Y = 380 (2 wooden blocks)
	create_custom_platform(1480.0, 380.0, 2, true)
	
	# Floating Platform in Gap 2: X = 1960, Y = 460 (2 wooden blocks -> high precision jump!)
	create_custom_platform(1960.0, 460.0, 2, true)
	
	# Segment 3 (Forest End / Port Start): X = 2200 to 3200 (Gap 3 is 400px wide!)
	add_ground_col.call(2200.0, 3200.0, GROUND_Y)
	
	# Floating Platform in Gap 3: X = 3360, Y = 440 (2 crates)
	create_custom_platform(3360.0, 440.0, 2, false)
	
	# Segment 4 (Port Middle): X = 3600 to 4500 (Gap 4 is 400px wide!)
	add_ground_col.call(3600.0, 4500.0, GROUND_Y)
	
	# Floating Platform in Gap 4: X = 4660, Y = 440 (2 crates)
	create_custom_platform(4660.0, 440.0, 2, false)
	
	# Segment 5 (Port End): X = 4900 to 5600.
	add_ground_col.call(4900.0, 5600.0, GROUND_Y)

	# 3. Add Forest Background sprites programmatically
	var bg_container := Node2D.new()
	bg_container.name = "ForestBackground"
	bg_container.z_index = -5
	add_child(bg_container)
	
	for x_pos in [689.0, 2072.0]:
		var sprite := Sprite2D.new()
		sprite.texture = load("res://background nivel 1/orig.png")
		sprite.position = Vector2(x_pos, 336.5)
		sprite.scale = Vector2(2.4, 2.18)
		bg_container.add_child(sprite)
		
		# Overlay layers
		for layer_num in ["1", "2", "3", "5"]:
			var tex_path = "res://background nivel 1/%s.png" % layer_num
			var layer_sprite := Sprite2D.new()
			layer_sprite.texture = load(tex_path)
			layer_sprite.position = Vector2(x_pos, 336.5)
			layer_sprite.scale = Vector2(2.4, 2.18)
			bg_container.add_child(layer_sprite)

	# 4. Spawn Port Containers and boxes on the right side
	var stack1_x := 2900.0
	var container1 := spawn_container(stack1_x, GROUND_Y, 2) # Blue
	var c_height := get_container_height(container1)
	spawn_container(stack1_x, GROUND_Y - c_height, 4) # Yellow on top
	
	# Climb helper crate
	spawn_box(stack1_x - 120.0, GROUND_Y, 1)
	spawn_box(stack1_x - 120.0, GROUND_Y - 50.0, 2)
	
	# Tunnel & Bridge Structure
	var tunnel_left_x := 3700.0
	var tunnel_right_x := 3950.0
	var bridge_x := 3825.0
	
	spawn_container(tunnel_left_x, GROUND_Y, 1)
	spawn_container(tunnel_right_x, GROUND_Y, 2)
	spawn_container(bridge_x, GROUND_Y - c_height, 4)

	# 5. Move Player to the starting point of Forest section
	var player = get_node_or_null("Player")
	if player:
		player.global_position = Vector2(150.0, 560.0)

	# 6. Spawn the LevelEnd portal programmatically with a gorgeous visual portal sprite and particles!
	var portal := Area2D.new()
	portal.name = "LevelEnd"
	portal.collision_layer = 8
	portal.collision_mask = 2
	portal.set_script(load("res://LevelEnd.gd"))
	portal.set("next_scene_path", "victory")
	
	# Draw portal rift sprite
	var portal_sprite := Sprite2D.new()
	portal_sprite.texture = load("res://icon.svg")
	portal_sprite.scale = Vector2(0.4, 1.1)
	portal_sprite.modulate = Color(0.6, 0.1, 0.9, 0.8) # Mystical glowing purple
	portal.add_child(portal_sprite)
	
	# Glowing magical sparks
	var particles := CPUParticles2D.new()
	particles.amount = 45
	particles.lifetime = 1.3
	particles.emission_shape = CPUParticles2D.EMISSION_SHAPE_RECTANGLE
	particles.emission_rect_extents = Vector2(15.0, 50.0)
	particles.direction = Vector2(0.0, -1.0)
	particles.spread = 30.0
	particles.gravity = Vector2(0.0, -30.0)
	particles.initial_velocity_min = 25.0
	particles.initial_velocity_max = 60.0
	particles.scale_amount_min = 2.0
	particles.scale_amount_max = 5.0
	particles.color = Color(0.8, 0.3, 1.0, 0.95)
	portal.add_child(particles)
	particles.emitting = true
	
	var portal_col := CollisionShape2D.new()
	var portal_shape := RectangleShape2D.new()
	portal_shape.size = Vector2(60.0, 110.0)
	portal_col.shape = portal_shape
	portal.add_child(portal_col)
	
	portal.global_position = Vector2(5300.0, GROUND_Y - 55.0)
	add_child(portal)

	# 7. Spawn MANY enemies (11 enemies!) at safe coordinates
	var enemy_scene = load("res://Enemy.tscn")
	if enemy_scene:
		# Reposition editor-placed enemy
		var e1 = get_node_or_null("Enemy")
		if e1:
			e1.global_position = Vector2(400.0, 580.0)
		else:
			e1 = enemy_scene.instantiate()
			e1.global_position = Vector2(400.0, 580.0)
			add_child(e1)
			
		# Array of safe coordinates on solid ground or platforms
		var spawn_positions := [
			Vector2(1100.0, 580.0),  # Forest Floor
			Vector2(1200.0, 380.0),  # Platform 1
			Vector2(1480.0, 300.0),  # Platform 2
			Vector2(1650.0, 580.0),  # Forest Floor
			Vector2(2300.0, 580.0),  # Port Floor 1
			Vector2(2900.0, 320.0),  # On top of double container stack
			Vector2(3700.0, 540.0),  # Near tunnel
			Vector2(3825.0, 320.0),  # On top of Bridge Container
			Vector2(4300.0, 580.0),  # Port Floor 2
			Vector2(5000.0, 580.0)   # Port Floor 3 (guards portal)
		]
		
		for pos in spawn_positions:
			var enemy = enemy_scene.instantiate()
			enemy.global_position = pos
			add_child(enemy)
		
	print("Nível 3 (Hardcore Gauntlet) carregado com sucesso!")

# Helper functions to build blocks programmatically
func create_custom_platform(start_x: float, y: float, num_blocks: int, is_forest: bool) -> StaticBody2D:
	var width := num_blocks * 32.0 * 2.0
	var height := 32.0 * 2.0
	
	var platform := StaticBody2D.new()
	platform.collision_layer = 1
	platform.collision_mask = 0
	
	var col := CollisionShape2D.new()
	var shape := RectangleShape2D.new()
	shape.size = Vector2(width, height)
	col.shape = shape
	platform.add_child(col)
	platform.global_position = Vector2(start_x + width / 2.0, y + height / 2.0)
	
	for i in range(num_blocks):
		var sprite := Sprite2D.new()
		if is_forest:
			sprite.texture = load("res://background nivel 2/3 Objects/3 Box/3.png")
		else:
			sprite.texture = load("res://background nivel 2/3 Objects/3 Box/1.png")
		sprite.scale = Vector2(2.0, 2.0)
		sprite.position = Vector2(-width / 2.0 + (i * 64.0) + 32.0, 0.0)
		platform.add_child(sprite)
		
	add_child(platform)
	return platform

func get_container_height(container: StaticBody2D) -> float:
	var sprite = container.get_node("Sprite2D") as Sprite2D
	if sprite and sprite.texture:
		return sprite.texture.get_size().y * sprite.scale.y
	return 120.0

func spawn_container(x: float, base_y: float, texture_num: int) -> StaticBody2D:
	var container := StaticBody2D.new()
	container.collision_layer = 1 # Terrain
	container.collision_mask = 0
	
	var sprite := Sprite2D.new()
	sprite.name = "Sprite2D"
	sprite.texture = load("res://background nivel 2/3 Objects/1 Cargos/%d.png" % texture_num)
	sprite.scale = Vector2(2.5, 2.5)
	
	var tex_size := sprite.texture.get_size() * 2.5
	container.global_position = Vector2(x, base_y - tex_size.y / 2)
	container.add_child(sprite)
	
	var collision := CollisionShape2D.new()
	var shape := RectangleShape2D.new()
	shape.size = tex_size
	collision.shape = shape
	container.add_child(collision)
	
	add_child(container)
	move_child(container, 0)
	
	return container

func spawn_box(x: float, base_y: float, texture_num: int) -> StaticBody2D:
	var box := StaticBody2D.new()
	box.collision_layer = 1
	box.collision_mask = 0
	
	var sprite := Sprite2D.new()
	sprite.texture = load("res://background nivel 2/3 Objects/3 Box/%d.png" % texture_num)
	sprite.scale = Vector2(2.5, 2.5)
	
	var tex_size := sprite.texture.get_size() * 2.5
	box.global_position = Vector2(x, base_y - tex_size.y / 2)
	box.add_child(sprite)
	
	var collision := CollisionShape2D.new()
	var shape := RectangleShape2D.new()
	shape.size = tex_size
	collision.shape = shape
	box.add_child(collision)
	
	add_child(box)
	move_child(box, 0)
	
	return box
