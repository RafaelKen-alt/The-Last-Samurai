extends Node2D

const GROUND_Y = 658.0

func _ready() -> void:
	# 1. Limpar as plataformas e colisões antigas que estavam feias/mal posicionadas
	var static_body = $StaticBody2D
	if static_body:
		var shape11 = static_body.get_node_or_null("CollisionShape2D11")
		var shape12 = static_body.get_node_or_null("CollisionShape2D12")
		
		# Apagar os blocos visuais antigos do TileMap
		_erase_tile_platform(Vector2(1088, 224))
		_erase_tile_platform(Vector2(800, 176))
		
		# Apagar os colisores físicos antigos
		if shape11: shape11.queue_free()
		if shape12: shape12.queue_free()

	# 2. Gerar o novo layout do porto de forma realista e bonita
	# Spawnar pilhas de contentores e caixotes
	# Usamos texturas de contentores de tamanho único (1, 2 e 4) para evitar sobreposições
	
	# Pilha 1 (Contentor único + Caixote em cima)
	var stack1_x = 340.0
	var container1 = spawn_container(stack1_x, GROUND_Y, 1) # Vermelho
	var c_height = get_container_height(container1)
	
	# Caixote no topo do Contentor 1
	var box1 = spawn_box(stack1_x, GROUND_Y - c_height, 1)
	
	# Pilha 2 (Dois contentores empilhados + Caixote em cima)
	var stack2_x = 455.0
	var container2_bottom = spawn_container(stack2_x, GROUND_Y, 2) # Azul
	var container2_top = spawn_container(stack2_x, GROUND_Y - c_height, 4) # Amarelo
	
	# Caixote no topo do Contentor 2
	var box2 = spawn_box(stack2_x, GROUND_Y - (c_height * 2), 2)
	
	# Pilha decorativa à esquerda (atrás do jogador, para detalhe de fundo)
	spawn_box(160.0, GROUND_Y, 3)
	spawn_box(130.0, GROUND_Y, 4)
	
	# 3. Adicionar o portal de fim de nível programaticamente para transição para o Nível 3
	var portal = Area2D.new()
	portal.name = "LevelEnd"
	portal.collision_layer = 8
	portal.collision_mask = 2
	portal.set_script(load("res://LevelEnd.gd"))
	portal.set("next_scene_path", "res://Nivel3.tscn")
	
	var portal_col = CollisionShape2D.new()
	var portal_shape = RectangleShape2D.new()
	portal_shape.size = Vector2(50.0, 720.0)
	portal_col.shape = portal_shape
	portal.add_child(portal_col)
	
	portal.global_position = Vector2(5300.0, 350.0)
	add_child(portal)
	
	print("Novo layout do Porto carregado com sucesso!")


func get_container_height(container: StaticBody2D) -> float:
	var sprite = container.get_node("Sprite2D") as Sprite2D
	if sprite and sprite.texture:
		return sprite.texture.get_size().y * sprite.scale.y
	return 120.0 # valor padrão

func spawn_container(x: float, base_y: float, texture_num: int) -> StaticBody2D:
	var container = StaticBody2D.new()
	container.collision_layer = 1 # Terreno
	container.collision_mask = 0   # Estático
	
	var sprite = Sprite2D.new()
	sprite.name = "Sprite2D"
	sprite.texture = load("res://background nivel 2/3 Objects/1 Cargos/%d.png" % texture_num)
	sprite.scale = Vector2(2.5, 2.5)
	
	var tex_size = sprite.texture.get_size() * 2.5
	# Posicionar de forma que a base fique exatamente em base_y
	container.global_position = Vector2(x, base_y - tex_size.y / 2)
	container.add_child(sprite)
	
	# Colisor correspondente ao tamanho real
	var collision = CollisionShape2D.new()
	var shape = RectangleShape2D.new()
	shape.size = tex_size
	collision.shape = shape
	container.add_child(collision)
	
	add_child(container)
	# Mover para trás na árvore de nós para que o jogador e inimigos fiquem à frente
	move_child(container, 0)
	
	return container

func spawn_box(x: float, base_y: float, texture_num: int) -> StaticBody2D:
	var box = StaticBody2D.new()
	box.collision_layer = 1 # Terreno
	box.collision_mask = 0
	
	var sprite = Sprite2D.new()
	sprite.texture = load("res://background nivel 2/3 Objects/3 Box/%d.png" % texture_num)
	sprite.scale = Vector2(2.5, 2.5)
	
	var tex_size = sprite.texture.get_size() * 2.5
	box.global_position = Vector2(x, base_y - tex_size.y / 2)
	box.add_child(sprite)
	
	var collision = CollisionShape2D.new()
	var shape = RectangleShape2D.new()
	shape.size = tex_size
	collision.shape = shape
	box.add_child(collision)
	
	add_child(box)
	# Mover para trás na árvore de nós
	move_child(box, 0)
	
	return box

func _erase_tile_platform(old_pos: Vector2, half_width_cells: int = 5, half_height_cells: int = 4) -> void:
	for name in ["Tiles", "Decorations"]:
		var map = get_node_or_null(name)
		if not map or not map is TileMapLayer:
			continue
			
		var old_cell = map.local_to_map(old_pos)
		
		# Apagar os tiles da plataforma na vizinhança da posição original
		for dx in range(-half_width_cells, half_width_cells + 1):
			for dy in range(-half_height_cells, half_height_cells + 1):
				var cell = old_cell + Vector2i(dx, dy)
				if map.get_cell_source_id(cell) != -1:
					map.erase_cell(cell)
