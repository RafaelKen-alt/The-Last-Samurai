extends CollisionShape2D

var player_ref = null

func _on_body_entered(body):
	if body.is_in_group("player"):
		player_ref = body

func _process(_delta):
	if player_ref != null:
		if not overlaps_body(player_ref):
			get_tree().call_deferred("reload_current_scene")
			player_ref = null

func _on_body_exited(body):
	if body == player_ref:
		player_ref = null
