extends Area2D

@export var margem_morte: float = 5.0
var player_ref = null

func _on_body_entered(body):
	if body.is_in_group("player"):
		player_ref = body

func _physics_process(_delta):
	if player_ref != null:
		if player_ref.global_position.y > global_position.y + margem_morte:
			get_tree().call_deferred("reload_current_scene")
			player_ref = null
